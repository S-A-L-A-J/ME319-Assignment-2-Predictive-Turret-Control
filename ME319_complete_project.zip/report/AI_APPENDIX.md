# Mandatory AI and computational-tools appendix (draft)

OpenAI Codex was used to inspect the supplied archives and assignment brief,
reconstruct the intended project structure, audit the estimator and controller
implementations, integrate the estimator, predictor, plant, controller and
firing logic, and draft reproducibility/report material. MATLAB R2025b was used
for the authoritative standardized simulations, controller analysis, result
tables, and figures. Python 3.13 with NumPy, SciPy and Matplotlib was used only
as an independent intermediate cross-check.

Significant accepted outputs were: (i) selection of the CV/CA IMM after a
frozen-parameter comparison, (ii) reproduction of its archived test metrics by
an independent Python implementation, (iii) first-principles derivation of the
motor-shaft-equivalent plant, and (iv) the gain-plus-low-pass compensator after
frequency-domain, time-domain, robustness and nonlinear saturation checks.

Significant modifications were: the four disconnected ZIP archives were
reorganized into one reproducible project; the older CV-only demonstration was
not used as the final estimator; and the firing supervisor was added to enforce
rising-edge pulses, recharge time, and the engagement-radius test. A naive rule
that fired while tracking the 0.50 s future angle was rejected after the
integrated simulation showed that it points ahead of the instantaneous target
when laser propagation is negligible. The accepted supervisor normally retains
predictive tracking for readiness, but temporarily requests the current
estimated line of sight before a pulse.

Validation used dimensional checks, physical-envelope assertions, an
independent reproduction of the 15-trajectory/100-noise-run estimator metrics,
closed-loop pole/margin calculations, nonlinear integration with voltage
clipping and hard stops, and 20 Monte Carlo measurement realizations for each
standardized scenario. Assumptions not supplied by the assignment (Gaussian
independence, +/-400 V, design-margin targets, and firing gate) are labeled as
choices. The instructor's final evaluation cases were unavailable and therefore
no final-case performance claim is made.
